module.exports = {
  styles: {
    'materialize': true,
  }
};